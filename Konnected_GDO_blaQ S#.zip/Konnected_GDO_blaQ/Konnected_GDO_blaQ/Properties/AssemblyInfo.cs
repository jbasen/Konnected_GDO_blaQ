﻿using System.Reflection;

[assembly: AssemblyTitle("Konnected_blaQ")]
[assembly: AssemblyCompany("HP Inc.")]
[assembly: AssemblyProduct("Konnected_blaQ")]
[assembly: AssemblyCopyright("Copyright © HP Inc. 2024")]
[assembly: AssemblyVersion("1.0.0.*")]

