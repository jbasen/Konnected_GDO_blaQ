﻿using System;
using System.Text;
using Crestron.SimplSharp;                          				// For Basic SIMPL# Classes
using Crestron.SimplSharp.Net.Http;
using System.Collections.Generic;
using Newtonsoft.Json;
using Crestron.SimplSharp.CrestronIO;
using System.Threading;


namespace Konnected_GDO_blaQ_Integration
{
	#region Classes
	//Event Classes
	public class SerialChangeEventArgs : EventArgs
	{
		public short Type { get; set; }
		public string Msg { get; set; }
		public string IP_Address { get; set; }
		public string Door_State { get; set; }
		public string Light_State { get; set; }
		public string Lock_State { get; set; }
		public short Position { get; set; }
		public string Current_Operation { get; set; }

		public SerialChangeEventArgs()
		{
		}

		public SerialChangeEventArgs(short Type, string Msg, string IP_Address, string Door_State, string Light_State, string Lock_State, short Position, string Current_Operation)
		{
			#region Set Class Data Elements from Parameters
			this.Type = Type;
			this.Msg = Msg;
			this.IP_Address = IP_Address;
			this.Door_State = Door_State;
			this.Light_State = Light_State;
			this.Lock_State = Lock_State;
			this.Position = Position;
			this.Current_Operation = Current_Operation;
			#endregion
		}
	}

	public static class SignalChangeEvents
	{
		public static event SerialChangedEventHandler onSerialValueChange;

		public static void SerialValueChange(short Type, string Msg, string IP_Address, string Door_State, string Light_State, string Lock_State, short Position, string Current_Operation)
		{
			SignalChangeEvents.onSerialValueChange(new SerialChangeEventArgs(Type, Msg, IP_Address, Door_State, Light_State, Lock_State, Position, Current_Operation));
		}
	}

	class Opener
	{
		public string IP_Address;
		public HttpClient client;
		public HttpClientRequest request;
		public HttpClientResponse response;

		//Constructors
		public Opener()
		{
		}

		public Opener(string IP_Address)
		{
			this.IP_Address = IP_Address;
		}
	}
	#endregion

	#region Delegates
	public delegate void SerialChangedEventHandler(SerialChangeEventArgs e);
	#endregion

	#region Enum
	enum Debug_Options
	{
		None,								//Don't do anything with debug information
		Console,							//Output debug information to the console
		Error_Log,							//Send debug information to the error log
		Both								//Send debug infomation to both the console and error log
	};
	#endregion

	public class Konnected_GDO_blaQ
	{
		#region Declarations
		private static Debug_Options Debug;
		private static List<Opener> Openers;

		private const short Type_Sensor_Update = 1;
		private const short Type_Comm_Error = 2;
		#endregion

		//****************************************************************************************
		// 
		//  Konnected_blaQ	-	Default Constructor
		// 
		//****************************************************************************************
		public Konnected_GDO_blaQ()
		{
		}

		//****************************************************************************************
		// 
		//  Konnected_blaQ	-	Default Destructor
		// 
		//****************************************************************************************
		~Konnected_GDO_blaQ()
		{
			foreach (Opener o in Openers)
			{
				o.client.Dispose();
				o.response.Dispose();
			}
		}

		//****************************************************************************************
		// 
		//  Initialize	-	Initialize system by setting up globals
		//					and setting up http server for update
		//					messages from Konnected.  Called by
		//					Comm Module
		// 
		//****************************************************************************************
		public short Initialize(short Debug)
		{
			#region Save Parameters in Globals
			Set_Debug_Message_Output(Debug);
			#endregion

			#region Create list for each opener
			try
			{
				Openers = new List<Opener>();
			}
			catch (Exception e)
			{
				CrestronConsole.PrintLine("Konnected_blaQ - Initialize - Can't create opener list: " + e);
				Crestron.SimplSharp.ErrorLog.Error("Konnected_blaQ - Initialize - Can't create opener list: " + e + "\n");
				return 0;
			}
			#endregion

			Debug_Message("Initialize", "SUCCESS");
			return 1;
		}

		//****************************************************************************************
		// 
		//  Initialize_blaQ	-	Initialize Opener Settings.
		// 
		//****************************************************************************************
		public void Initialize_blaQ(string IP_Address)
		{

			Debug_Message("Initialize_blaQ", "IP_Address = " + IP_Address);

			#region Parameter Checking
			//Check for duplicate
			if (Openers.Exists(x => x.IP_Address == IP_Address))
			{
				//Duplicate Found
				Debug_Message("Initialize_blaQ", "Duplicate Opener Registration - IP_Address = " + IP_Address);
				return;
			}
			#endregion

			#region Add Device to List
			//Add Device to list of Devices using device type enum
			try
			{
				Opener Opener_Data = new Opener(IP_Address);
				Openers.Add(Opener_Data);
			}
			catch (Exception e)
			{
				CrestronConsole.PrintLine("Konnected_blaQ - Initialize_blaQ - Can't Register Opener: IP_Address = " + IP_Address + ", Error = " + e);
				Crestron.SimplSharp.ErrorLog.Error("Konnected_blaQ - Initialize_blaQ - Can't Register Opener: IP_Address = " + IP_Address + ", Error = " + e);
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  SSE_Init	-	Start server side events receiver
		// 
		//****************************************************************************************
		public void SSE_Init(string IP_Address)
		{
			Debug_Message("SSE_Init", "Starting - IP_Address = " + IP_Address);

			#region Get Opener Info
			Opener o = Openers.Find(x => x.IP_Address == IP_Address);
			#endregion

			#region Create URL
			string url = "http://" + o.IP_Address + "/events";
			Debug_Message("SSE_Init", "url = " + url);
			#endregion

			#region Client Connection
			o.client = new HttpClient();
			o.request = new HttpClientRequest();
			o.request.RequestType = RequestType.Get;
			o.request.Url.Parse(url);
			o.request.KeepAlive = true;
			o.request.Header.SetHeaderValue("Accept", "text/event-stream");
			o.request.Header.SetHeaderValue("Accept-Encoding", "gzip,deflate");
			o.request.Header.SetHeaderValue("Accept-Language", "en-US,en;q=0.9");

			//Get Response
			o.response = o.client.Dispatch(o.request);
			if (o.response.Code < 200 || o.response.Code >= 300)
			{
				// server threw a error.
				string err = "Konnected_blaQ - SSE_Init - http response code: " + o.response.Code;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				return;
			}
			#endregion

			CrestronInvoke.BeginInvoke(parameter => { SSE_Thread(o); });
		}

		//****************************************************************************************
		// 
		//  SSE_Thread	-	Separate thread for parsing SSE data and passing it back
		// 
		//****************************************************************************************
		private void SSE_Thread(Opener o)
		{
			string s;

			Debug_Message("SSE_Thread", "Started - Board = " + o.IP_Address);

			while (true)
			{
				s = o.response.DataConnection.ReadLine();
				if (s.StartsWith("data: {\"id\":") == true)
				{
					Debug_Message("SSE_Thread", "s = " + s);
				}
				//Eliminate Unwanted Messages
				if ((string.IsNullOrEmpty(s) == false) && ((s.StartsWith("data: {\"id\":\"cover-garage_door\"") == true)
					|| (s.StartsWith("data: {\"id\":\"light-garage_light\"") == true) || (s.StartsWith("data: {\"id\":\"lock-lock\"") == true)))
				{
					#region Isolate JSON
					int i = s.IndexOf("{") - 1;
					s = s.Substring(i);
					#endregion
					if (s != "{}")
					{
						try
						{
							#region Parse
							Debug_Message("SSE_Thread", "s = " + s);
							SSEvent e = JsonConvert.DeserializeObject<SSEvent>(s);
							#endregion

							//Pass Back to S+
							if (e.id == "cover-garage_door")
							{
								short pos = Convert.ToInt16(Math.Round((e.position * 100), 0));
								SignalChangeEvents.SerialValueChange(Type_Sensor_Update, "", o.IP_Address, e.state, "", "", pos, e.current_operation);
							}
							else if (e.id == "light-garage_light")
							{
								SignalChangeEvents.SerialValueChange(Type_Sensor_Update, "", o.IP_Address, "", e.state, "", 0, "");
							}
							else if (e.id == "lock-lock")
							{
								SignalChangeEvents.SerialValueChange(Type_Sensor_Update, "", o.IP_Address, "", "", e.state, 0, "");
							}
							else
							{
								Debug_Message("SSE_Thread", "Unhandled JSON - id = " + e.id + ", state = " + e.state);
							}
						}
						catch (Exception ex)
						{
							CrestronConsole.PrintLine("Konnected - SSE_Thread - " + ex.Message);
						}
					}
				}
				if (o.response.DataConnection.Connected == false)
				{
					Debug_Message("SSE_Thread", "response.DataConnection.Connected == false");
				}
			}
		}

		//****************************************************************************************
		// 
		//  Get_Door_State	-	Retrieves the state of a door/opener
		// 
		//****************************************************************************************
		public void Get_Door_State(string IP_Address)
		{
			HttpClient client = null;

			Debug_Message("Get_Door_State", "IP_Address = " + IP_Address);

			#region Get Opener Info
			Opener o = Openers.Find(x => x.IP_Address == IP_Address);
			#endregion

			#region Create url
			string url = "http://" + o.IP_Address + "/cover/garage_door/";
			Debug_Message("Get_Door_State", "URL: " + url);
			#endregion

			#region Send Command
			try
			{
				//Create http client
				client = new HttpClient();
				//client.Verbose = true;
				HttpClientRequest request = new HttpClientRequest();
				HttpClientResponse response;

				//Send http client request
				request.RequestType = Crestron.SimplSharp.Net.Http.RequestType.Get;
				request.KeepAlive = false;
				request.Url.Parse(url);

				//Get response
				response = client.Dispatch(request);
				if (response.Code < 200 || response.Code >= 300)
				{
					// server threw a error.
					string err = "Konnected_blaQ - Get_Door_State - http response code: " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				}
				else
				{
					Debug_Message("Get_Door_State", "Success - response.ContentString = " + response.ContentString);
					try
					{
						#region Parse
						SSEvent e = JsonConvert.DeserializeObject<SSEvent>(response.ContentString);
						#endregion

						//Pass Back to S+
						short pos = Convert.ToInt16(Math.Round((e.position * 100), 0));
						SignalChangeEvents.SerialValueChange(Type_Sensor_Update, "", o.IP_Address, e.state, "", "", pos, e.current_operation);
					}
					catch (Exception ex)
					{
						CrestronConsole.PrintLine("Konnected - Get_Door_State - " + ex.Message);
					}
				}
			}
			catch (Exception e)
			{
				string err = "Konnected_blaQ - Get_Door_State - Error Sending Device Command: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
			}
			finally
			{
				if (client != null)
				{
					client.Dispose();
				}
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Get_Light_State	-	Retrieves the state of the opener light
		// 
		//****************************************************************************************
		public void Get_Light_State(string IP_Address)
		{
			HttpClient client = null;

			Debug_Message("Get_Light_State", "IP_Address = " + IP_Address);

			#region Get Opener Info
			Opener o = Openers.Find(x => x.IP_Address == IP_Address);
			#endregion

			#region Create url
			string url = "http://" + o.IP_Address + "/light/garage_light/";
			Debug_Message("Get_Light_State", "URL: " + url);
			#endregion

			#region Send Command
			try
			{
				//Create http client
				client = new HttpClient();
				//client.Verbose = true;
				HttpClientRequest request = new HttpClientRequest();
				HttpClientResponse response;

				//Send http client request
				request.RequestType = Crestron.SimplSharp.Net.Http.RequestType.Get;
				request.KeepAlive = false;
				request.Url.Parse(url);

				//Get response
				response = client.Dispatch(request);
				if (response.Code < 200 || response.Code >= 300)
				{
					// server threw a error.
					string err = "Konnected_blaQ - Get_Light_State - http response code: " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				}
				else
				{
					Debug_Message("Get_Light_State", "Success - response.ContentString = " + response.ContentString);
					try
					{
						#region Parse
						SSEvent e = JsonConvert.DeserializeObject<SSEvent>(response.ContentString);
						#endregion

						//Pass Back to S+
						SignalChangeEvents.SerialValueChange(Type_Sensor_Update, "", o.IP_Address, "", e.state, "", 0, "");
					}
					catch (Exception ex)
					{
						CrestronConsole.PrintLine("Konnected - Get_Light_State - " + ex.Message);
					}
				}
			}
			catch (Exception e)
			{
				string err = "Konnected_blaQ - Get_Light_State - Error Sending Device Command: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
			}
			finally
			{
				if (client != null)
				{
					client.Dispose();
				}
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Get_Lock_State	-	Retrieves the state of the remote lock
		// 
		//****************************************************************************************
		public void Get_Lock_State(string IP_Address)
		{
			HttpClient client = null;

			Debug_Message("Get_Lock_State", "IP_Address = " + IP_Address);

			#region Get Opener Info
			Opener o = Openers.Find(x => x.IP_Address == IP_Address);
			#endregion

			#region Create url
			string url = "http://" + o.IP_Address + "/lock/lock/";
			Debug_Message("Get_Lock_State", "URL: " + url);
			#endregion

			#region Send Command
			try
			{
				//Create http client
				client = new HttpClient();
				//client.Verbose = true;
				HttpClientRequest request = new HttpClientRequest();
				HttpClientResponse response;

				//Send http client request
				request.RequestType = Crestron.SimplSharp.Net.Http.RequestType.Get;
				request.KeepAlive = false;
				request.Url.Parse(url);

				//Get response
				response = client.Dispatch(request);
				if (response.Code < 200 || response.Code >= 300)
				{
					// server threw a error.
					string err = "Konnected_blaQ - Get_Lock_State - http response code: " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				}
				else
				{
					Debug_Message("Get_Lock_State", "Success - response.ContentString = " + response.ContentString);
					try
					{
						#region Parse
						SSEvent e = JsonConvert.DeserializeObject<SSEvent>(response.ContentString);
						#endregion

						//Pass Back to S+
						SignalChangeEvents.SerialValueChange(Type_Sensor_Update, "", o.IP_Address, "", "", e.state, 0, "");
					}
					catch (Exception ex)
					{
						CrestronConsole.PrintLine("Konnected - Get_Lock_State - " + ex.Message);
					}
				}
			}
			catch (Exception e)
			{
				string err = "Konnected_blaQ - Get_Lock_State - Error Sending Device Command: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
			}
			finally
			{
				if (client != null)
				{
					client.Dispose();
				}
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Opener_Command	-	Send command to opener
		// 
		//****************************************************************************************
		public void Opener_Command(string IP_Address, string param1, string param2, string param3, string param4, string param5)
		{
			HttpClient client = null;

			Debug_Message("Opener_Command", "IP_Address = " + IP_Address);

			#region Get Opener Info
			Opener o = Openers.Find(x => x.IP_Address == IP_Address);
			#endregion

			#region Create url
			string url = "http://" + o.IP_Address + "/" + param1 + "/" + param2 + "/" + param3;
			if ((string.IsNullOrEmpty(param4) == false) && (string.IsNullOrEmpty(param4) == false))
			{
				url += "?" + param4 + "=" + param5;
			}
			Debug_Message("Opener_Command", "URL: " + url);
			#endregion

			#region Send Command
			try
			{
				//Create http client
				client = new HttpClient();
				//client.Verbose = true;
				HttpClientRequest request = new HttpClientRequest();
				HttpClientResponse response;

				//Send http client request
				request.RequestType = Crestron.SimplSharp.Net.Http.RequestType.Post;
				request.KeepAlive = false;
				request.Url.Parse(url);

				//Get response
				response = client.Dispatch(request);
				if (response.Code < 200 || response.Code >= 300)
				{
					// server threw a error.
					string err = "Konnected_blaQ - Opener_Command - http response code: " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				}
				else
				{
					Debug_Message("Konnected_blaQ", "Success - response.ContentString = " + response.ContentString);
				}
			}
			catch (Exception e)
			{
				string err = "Konnected_blaQ - Opener_Command - Error Sending Device Command: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
			}
			finally
			{
				if (client != null)
				{
					client.Dispose();
				}
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Parse_Data_Substring	-	Parse Data Element from Json
		// 
		//****************************************************************************************
		public static string Parse_Data_Substring(string s, string section, string id, string ending_char)
		{
			int index1, index2, section_index;

			//Reporting of not finding section or string as an error eliminted because 
			//there are too many situations where the code has to accomodate the fact
			//that Konnected will send back very different messages depending on exactly
			//what setting was changed on a device.  Thermostat is the prime example

			//if data element located within a specific section of json, go to that section
			if (section != "")
			{
				section_index = s.IndexOf(section, 0);
				if (section_index == -1)
				{
					//CrestronConsole.PrintLine("Konnected_blaQ - Parse_Data_Substring - Unable to Locate " + section + " in " + s);
					//Crestron.SimplSharp.ErrorLog.Error("Konnected_blaQ - Parse_Data_Substring - Unable to Locate " + section + " in " + s);
					return "";
				}
				else
				{
					section_index += section.Length;
				}
			}
			else
			{
				section_index = 0;
			}

			//get index to start of value
			index1 = s.IndexOf(id, section_index);
			if (index1 == -1)
			{
				CrestronConsole.PrintLine("Konnected_blaQ - Parse_Data_Substring - Unable to Locate " + id + " in " + s);
				Crestron.SimplSharp.ErrorLog.Error("Konnected_blaQ - Parse_Data_Substring - Unable to Locate " + id + " in " + s);
				return "";
			}
			else
			{
				index1 += id.Length;
			}

			//get index to end of value
			index2 = s.IndexOf(ending_char, (index1 + 1));
			if (index2 == -1)
			{
				CrestronConsole.PrintLine("Konnected_blaQ - Parse_Data_Substring - Unable to Locate terminating " + ending_char + " for " + id + " in " + s);
				Crestron.SimplSharp.ErrorLog.Error("Konnected_blaQ - Parse_Data_Substring - Unable to Locate terminating " + ending_char + " for " + id + " in " + s);
				return "";
			}

			//get value substring and pass it back
			return s.Substring(index1, index2 - index1);
		}

		//****************************************************************************************
		// 
		//  Set_Debug_Message_Output	-	Save whether debug messages will be output
		//									to console, error log, both, or not sent
		//									0 = None, 1 = Console, 2 = Error Log, 3 = Both
		// 
		//****************************************************************************************
		public void Set_Debug_Message_Output(short Debug)
		{
			//Save debug message setting as an enum
			switch (Debug)
			{
				case 0:
					Konnected_GDO_blaQ.Debug = Debug_Options.None;
					break;

				case 1:
					Konnected_GDO_blaQ.Debug = Debug_Options.Console;
					break;

				case 2:
					Konnected_GDO_blaQ.Debug = Debug_Options.Error_Log;
					break;

				case 3:
					Konnected_GDO_blaQ.Debug = Debug_Options.Both;
					break;
			}
		}

		//****************************************************************************************
		// 
		//  Debug_Message	-	Send Debug Message to Console or Error Log
		//						Depending on Selection
		// 
		//****************************************************************************************
		private static void Debug_Message(string Name, string s)
		{
			const int characters_per_line = 250;
			int start_index = 0;
			int length = characters_per_line;

			//json responses are too large for Simpl Debugger to display on a single line
			//so, we break them up into chunks of 250 characters to be printed on 1 line
			while (start_index < s.Length)
			{
				if ((start_index + characters_per_line) > s.Length)
				{
					length = s.Length - start_index;
				}

				string sub = s.Substring(start_index, length);

				if ((Debug == Debug_Options.Console) || (Debug == Debug_Options.Both))
				{
					CrestronConsole.PrintLine("Konnected_blaQ - " + Name + " - " + sub);
				}

				if ((Debug == Debug_Options.Error_Log) || (Debug == Debug_Options.Both))
				{
					Crestron.SimplSharp.ErrorLog.Notice("Konnected_blaQ - " + Name + " - " + sub + "\n");
				}

				start_index += characters_per_line;
			}
		}

		//****************************************************************************************
		// 
		//  Report_Communications_Error	-	Sends a communications error information
		//									to the receiver module for reporting
		// 
		//****************************************************************************************
		private void Report_Communications_Error(string msg)
		{
			SignalChangeEvents.SerialValueChange(Type_Comm_Error, msg, "", "", "", "", 0, "");
		}
	}

	public class SSEvent
	{
		public string id { get; set; }
		public string state { get; set; }
		public string current_operation { get; set; }
		public double position { get; set; }
	}
}
